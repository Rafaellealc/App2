﻿using Dapper.Contrib.Extensions;
using Dapper;
using Framework.AcessoDados.Dapper;
using Framework.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Framework.Excecao;


namespace Aplicacao.Dominio.DapperObjetos
{
   [Table("Pessoa")]
   public class Pessoa
    {
        /// <summary>
        /// CPF
        /// </summary>
        ///
        [Key]
       public long CPF { get; set; }

        /// <summary>
        /// RG
        /// </summary>
        public long RG { get; set; }

        /// <summary>
        /// Primeiro Nome
        /// </summary>
        public string FIRST_NAME { get; set; }

        /// <summary>
        /// Último Nome
        /// </summary>
        public string LAST_NAME { get; set; }

        /// <summary>
        /// Endereço
        /// </summary>
        public string ADDRESS { get; set; }


        public bool Incluir()
        {
            try
            {

                using (var cnx = new DapperContext().Connection)
                {
                    cnx.Insert(this,true);
                }

            }
            catch (Exception ex)
            {
                TratarExcecao.Tratar(ex);
                return false;
            }
         
            return true;
        }

        public bool Deletar(long value)
        {
            try
            {
                this.CPF = value;

                using (var cnx = new DapperContext().Connection)
                {
                    cnx.Delete(this);
                }

            }
            catch (Exception ex)
            {
                TratarExcecao.Tratar(ex);
                return false;
            }

            return true;
        }

        public bool Atualizar(long value)
        {
            try
            {
                using (var cnx = new DapperContext().Connection)
                {                   
                    return cnx.Update(this);
                }

            }
            catch (Exception ex)
            {
                TratarExcecao.Tratar(ex);
                return false;
            }           
        }

        public List<Pessoa> Selecionar()
        {
            List<Pessoa> list = new List<Pessoa>();

//            try
//            {
//                using (var cnx = new DapperContext().Connection)
//                {
//                    list =  cnx.Query<Pessoa>(
//                        @"SELECT CPF,
//                                 RG,
//                                 FIRST_NAME,
//                                 LAST_NAME,
//                                 ADDRESS
//                                      
//                          FROM PESSOA").ToList();                   
//                }
//            }
//            catch (Exception ex)
//            {
//                TratarExcecao.Tratar(ex);
//                return list;
//            }

            return new List<Pessoa>
            {
               new Pessoa { 
               CPF = 39235235804,
               RG = 466101417,
               FIRST_NAME = "Rafael",
               LAST_NAME = "Leal da Costa",
               ADDRESS = "Rua Itália, 418 - Diadema"
               }

            };
        }

        public bool Selecionar(long value)
        {          

            try
            {

                using (var cnx = new DapperContext().Connection)
                {
                    var query = cnx.Query<Pessoa>(
                        String.Format("SELECT * FROM Pessoa WHERE cpf = '{0}'", value)
                    ).FirstOrDefault();


                    if (query != null)
                    {
                        this.CPF = query.CPF;
                        this.RG = query.RG;
                        this.FIRST_NAME = query.FIRST_NAME;
                        this.LAST_NAME = query.LAST_NAME;
                        this.ADDRESS = query.ADDRESS;                      
                    }
                    else
                    {                    
                        return false;
                    }

                }

            }
            catch (Exception ex)
            {
                TratarExcecao.Tratar(ex);
                return false;
            }
        
            return true;
        }

    }  

}
