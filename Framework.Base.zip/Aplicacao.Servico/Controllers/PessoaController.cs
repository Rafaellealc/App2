﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Aplicacao.Dominio.Objetos;
using Aplicacao.Dominio.DapperObjetos;

namespace Aplicacao.Servico.Controllers
{
    public class PessoaController : ApiController
    {
        Pessoa pessoa = new Pessoa();

        public IEnumerable<TOPessoa> Get()
        {          
            return pessoa.Selecionar()
                         .Select(x=> new TOPessoa
                         {
                             cpf = x.CPF,
                             rg = x.RG,
                             firstName = x.FIRST_NAME,
                             lastName = x.LAST_NAME,
                             address = x.ADDRESS
                             
                         }).ToList();                     
        }

        public TOPessoa Get(long cpf)
        {

            if (pessoa.Selecionar(cpf))
            {
               
                    return new TOPessoa
                    {
                        cpf = pessoa.CPF,
                        rg = pessoa.RG,
                        firstName = pessoa.FIRST_NAME,
                        lastName = pessoa.LAST_NAME,
                        address = pessoa.ADDRESS,

                        sucesso = true,
                        mensagem = string.Empty
                    };                             
            }
            else
            {
                return new TOPessoa
                {
                    sucesso = false,
                    mensagem = "Registro não encontrado"
                };
            }                             
        }

        // POST api/values
        [HttpPost]
        public void Post([FromBody]TOPessoa value)
        {
            if (value != null)
            {
                pessoa.CPF = value.cpf;
                pessoa.RG = value.rg;
                pessoa.FIRST_NAME = value.firstName;
                pessoa.LAST_NAME = value.lastName;
                pessoa.ADDRESS = value.address;

                if (pessoa.Incluir())
                {
                    //tratar retorno
                }
                else
                {
                    //tratar retorno
                }

            }
            else
            {
                //tratar retorno
            }

        }

        // PUT api/values/5
        public void Put(long cpf, [FromBody]TOPessoa value)
        {
            if (value != null)
            {
                pessoa.RG = value.rg;
                pessoa.FIRST_NAME = value.firstName;
                pessoa.LAST_NAME = value.lastName;
                pessoa.ADDRESS = value.address;

                if (pessoa.Atualizar(value.cpf))
                {
                    //tratar retorno
                }
                else
                {
                    //tratar retorno
                }
            }
            else
            {
                //tratar retorno
            }
        }

        // DELETE api/values/5
        public void Delete(long cpf)
        {
            if (cpf != null)
            {
                if (pessoa.Deletar(cpf))
                {
                    //tratar retorno
                }
                else
                {
                    //tratar retorno
                }
            }
            else
            {
                //tratar retorno
            }
        }
    }
}
