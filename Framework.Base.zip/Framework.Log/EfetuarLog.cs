﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Framework.Log
{
   public static class EfetuarLog
    {

       public static void Logger(string message)
       {
           //Persiste no banco o stack trace, horário, informações do cliente e mensagem
           // para fins de rastreabilidade de erros e log de negócios
       }
    }
}
