﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Framework.Log;

namespace Framework.Excecao
{
  public static class TratarExcecao
    {

      public static void Tratar(Exception ex)
      {
          //Objetivo é tratar a exceção, apresentar ao usuário que ocorreu um problema e gravar um log
          EfetuarLog.Logger(ex.Message);
      }
    }
}
