﻿using Framework.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Aplicacao.Dominio.Objetos
{
    public class TOPessoa : TOBase
    {

        /// <summary>
        /// CPF
        /// </summary>
        public long cpf { get; set; }

        /// <summary>
        /// RG
        /// </summary>
        public long rg { get; set; }

        /// <summary>
        /// Primeiro Nome
        /// </summary>
        public string firstName { get; set; }

        /// <summary>
        /// Último Nome
        /// </summary>
        public string lastName { get; set; }

        /// <summary>
        /// Endereço
        /// </summary>
        public string address { get; set; }


    }
}