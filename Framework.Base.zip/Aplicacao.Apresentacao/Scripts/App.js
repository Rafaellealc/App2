﻿var app = angular.module('app', []);

app.controller("Pessoa", function ($scope, $http) {

    $scope.step = "Lista";
    $scope.cpfEnabled = true;  


    $scope.carregarLista = function () {
        return $http.get('http://localhost:49539/api/Pessoa').
             success(function (data) {             

                 $scope.Pessoas = data;
                
       });
    }

    $scope.alterar = function (value) {


        $scope.CPF = value.cpf;
        $scope.RG = value.rg;
        $scope.firstName = value.firstName;
        $scope.lastName = value.lastName;
        $scope.address = value.address;

        $scope.step = "Cadastro";            

    }

    $scope.cadastrar = function () {

        $scope.CPF = "";
        $scope.RG = "";
        $scope.firstName = "";
        $scope.lastName = "";
        $scope.address = "";
        
        $scope.step = "Cadastro";
    }

    $scope.excluir = function (value) {

        $scope.step = "Cadastro";
    }

    $scope.incluir = function () {       

        var data =
            $.param({
                cpf: $scope.CPF,
                rg: $scope.RG,
                firstName: $scope.firstName,
                lastName: $scope.lastName,
                address: $scope.address
            });             

        $http.post("http://localhost:49539/api/Pessoa",
                   data,
                   { headers: { 'Content-Type': 'application/x-www-form-urlencoded' }                                              

                   }).success(function (data, status) {

                       $scope.carregarLista();
                       $scope.step = "Lista";

                   })                       
    
       
    }

    $scope.voltar = function () {

        $scope.step = "Lista";
    }

});